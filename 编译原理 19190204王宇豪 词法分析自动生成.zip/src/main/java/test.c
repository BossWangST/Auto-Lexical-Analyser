#include <stdio.h>

int main()
{
    int a=9;
    printf("%x\n",a);
    int b=!a;
    int c=~a;
    printf("!a=%x\n",b);
    printf("~a=%x\n",c);
    return 0;
}

